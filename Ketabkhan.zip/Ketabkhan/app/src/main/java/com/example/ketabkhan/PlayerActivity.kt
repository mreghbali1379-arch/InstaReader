package com.example.ketabkhan

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

/** The reading screen: speaks the book page by page and offers the tools. */
class PlayerActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var meta: BookMeta
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var playing = false
    @Volatile private var token = 0
    private var page = 0
    private var text = ""
    private var sents: List<Seg> = emptyList()
    private var cur = 0
    private var curOff = 0
    private var lastLang = ""
    private var playStart = 0L
    private var held = false
    private var loaded = false
    private var skip: List<String> = emptyList()
    private val h = Handler(Looper.getMainLooper())

    private lateinit var tv: TextView
    private lateinit var scroll: ScrollView
    private lateinit var titleView: TextView
    private lateinit var pageLabel: TextView
    private lateinit var status: TextView
    private lateinit var playBtn: android.widget.ImageButton

    // saving and recording
    private var pendingSave: File? = null
    private val saver = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val f = pendingSave
        if (uri != null && f != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                Ui.toast(this, "بارگیری کامل شد")
            } catch (e: Exception) { Ui.toast(this, "بارگیری انجام نشد.") }
        }
    }
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var player: MediaPlayer? = null
    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else Ui.toast(this, "برای ضبط صدا به مجوز میکروفون نیاز است.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val m = if (id == null) null else BookStore.load(this, id)
        if (m == null) { finish(); return }
        meta = m
        page = meta.page
        buildUi()
        skip = BookStore.skipWords(this, meta.id)
        tts = TextToSpeech(this, this, Prefs.engine(this))
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        Ui.rtl(root)
        val pad = Ui.dp(this, 8)
        root.setPadding(pad, pad, pad, pad)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.icon(this, R.drawable.ic_back, "بازگشت", 44) { finish() })
        titleView = Ui.label(this, meta.name, 18f, Ui.TEXT, true)
        titleView.maxLines = 1
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        androidx.core.view.ViewCompat.setAccessibilityHeading(titleView, true)
        top.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        pageLabel = Ui.label(this, "", 14f, Ui.TEXT2)
        top.addView(pageLabel)
        root.addView(top)

        status = Ui.label(this, "", 14f, Ui.ACCENT)
        root.addView(status)

        scroll = ScrollView(this)
        tv = Ui.label(this, "", Prefs.fontSp(this).toFloat(), Ui.TEXT)
        tv.setLineSpacing(0f, 1.3f)
        val tp = Ui.dp(this, 10)
        tv.setPadding(tp, tp, tp, tp)
        tv.setTextIsSelectable(false)
        scroll.addView(tv)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // media controls are always left-to-right like on every player
        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        ctl.layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
        ctl.addView(Ui.icon(this, R.drawable.ic_prev, "قبلی") { step(-1) })
        ctl.addView(Ui.icon(this, R.drawable.ic_rew, "۱۰ ثانیه به عقب") { jump(-1) })
        playBtn = Ui.icon(this, R.drawable.ic_play, "پخش", 64) { togglePlay() }
        ctl.addView(playBtn)
        ctl.addView(Ui.icon(this, R.drawable.ic_ff, "۱۰ ثانیه به جلو") { jump(1) })
        ctl.addView(Ui.icon(this, R.drawable.ic_next, "بعدی") { step(1) })
        root.addView(ctl)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val b1 = Ui.button(this, "ابزارها", false) { toolsMenu() }
        val b2 = Ui.button(this, "تنظیمات", false) { settingsMenu() }
        val b3 = Ui.button(this, "بازپخش", false) { replay() }
        for (b in listOf(b1, b2, b3)) row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        setContentView(root)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            Ui.toast(this, "متن‌به‌گفتار نصب نیست یا راه‌اندازی نشد. لطفا یک موتور متن‌به‌گفتار نصب کنید.")
            return
        }
        ttsReady = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == "u$token") h.post { if (playing) advance() }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == "u$token") h.post { if (playing) { pause(); Ui.toast(this@PlayerActivity, "خواندن انجام نشد. زبان یا صدا را در تنظیمات بررسی کنید.") } }
            }
        })
        applyVoiceSettings()
    }

    private fun applyVoiceSettings() {
        tts?.setSpeechRate(Prefs.rate(this))
        tts?.setPitch(Prefs.pitch(this))
    }

    override fun onResume() {
        super.onResume()
        if (!::meta.isInitialized) return
        Processor.listener = { onProgress() }
        refreshMeta()
        if (!loaded) tryLoad()
        updateStatus()
    }

    override fun onPause() {
        super.onPause()
        if (!::meta.isInitialized) return
        Processor.listener = null
        if (playing && !Prefs.bgRead(this)) pause()
        savePosition()
    }

    override fun onDestroy() {
        if (!::meta.isInitialized) { super.onDestroy(); return }
        if (playing) pause()
        stopVoicePlayer()
        try { recorder?.release() } catch (e: Exception) { }
        tts?.stop()
        tts?.shutdown()
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- loading pages

    private fun refreshMeta() {
        val n = BookStore.load(this, meta.id) ?: return
        meta.total = n.total
        meta.done = n.done
        meta.name = n.name
        titleView.text = n.name
    }

    private fun onProgress() {
        refreshMeta()
        if (!loaded) tryLoad()
        updateStatus()
    }

    private fun available(): Int { refreshMeta(); return meta.done }

    private fun updateStatus() {
        pageLabel.text = if (meta.total > 0) "صفحه‌ی ${page + 1} از ${meta.total}" else ""
        status.text = when {
            meta.total == 0 && Processor.isRunning(meta.id) -> "در حال آماده‌سازی..."
            meta.done < meta.total && Processor.isRunning(meta.id) -> "در حال پردازش صفحه‌ی ${meta.done + 1} از ${meta.total}"
            meta.done < meta.total -> "پردازش ناتمام است (${meta.done} از ${meta.total} صفحه). از «ابزارها» می‌توانید آن را کامل کنید."
            else -> ""
        }
    }

    private fun tryLoad() {
        if (meta.done <= 0) {
            tv.text = "در حال ساختن کتاب صوتی... لطفا منتظر بمانید"
            return
        }
        loaded = true
        val p = if (page < meta.done) page else 0
        loadPage(p, if (p == meta.page) meta.offset else 0)
    }

    private fun loadPage(p: Int, offset: Int) {
        page = p.coerceIn(0, maxOf(meta.done - 1, 0))
        text = BookStore.pageText(this, meta.id, page)
        sents = TextUtil.sentences(text)
        cur = TextUtil.indexAt(sents, offset)
        curOff = sents.getOrNull(cur)?.start ?: 0
        tv.textSize = Prefs.fontSp(this).toFloat()
        render(null)
        scroll.scrollTo(0, 0)
        updateStatus()
        if (Prefs.pageSound(this) && loaded) beep()
    }

    private fun render(s: Seg?) {
        if (text.isBlank()) { tv.text = "صفحه خالی است.\nمتنی پیدا نشد."; return }
        if (s == null) { tv.text = text; return }
        val sp = SpannableString(text)
        sp.setSpan(BackgroundColorSpan(0x663399FF), s.start, s.end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        tv.text = sp
        tv.post {
            val l = tv.layout
            if (l != null && s.start < text.length) {
                val y = l.getLineTop(l.getLineForOffset(s.start))
                scroll.smoothScrollTo(0, maxOf(0, y - Ui.dp(this, 80)))
            }
        }
    }

    private fun beep() {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 40).startTone(ToneGenerator.TONE_PROP_BEEP, 80) } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- speaking

    private fun speechText(raw: String): String {
        var s = raw
        for (w in skip) s = s.replace(w, " ", true)
        return s
    }

    private fun setLangFor(s: String) {
        val t = tts ?: return
        val l = TextUtil.lang(s)
        if (l == lastLang) return
        lastLang = l
        if (l == "fa") TtsUtil.usePersian(t) else TtsUtil.useEnglish(t)
        val vn = if (l == "fa") Prefs.voiceFa(this) else Prefs.voiceEn(this)
        if (vn != null) {
            try { t.voices?.firstOrNull { it.name == vn }?.let { t.voice = it } } catch (e: Exception) { }
        }
    }

    private fun speak(say: String) {
        val t = tts ?: return
        setLangFor(say)
        token++
        t.speak(say, TextToSpeech.QUEUE_FLUSH, null, "u$token")
    }

    private fun speakCurrent() {
        if (!ttsReady) { Ui.toast(this, "متن‌به‌گفتار آماده نیست."); return }
        if (sents.isEmpty() || cur >= sents.size) { h.post { if (playing) nextPageAuto() }; return }
        val sg = sents[cur]
        curOff = sg.start
        render(sg)
        val say = speechText(text.substring(sg.start, sg.end))
        if (say.isBlank()) { h.post { if (playing) advance() }; return }
        speak(say)
    }

    private fun advance() {
        cur++
        if (cur < sents.size) speakCurrent() else nextPageAuto()
    }

    private fun nextPageAuto() {
        val av = available()
        when {
            page + 1 < av -> { loadPage(page + 1, 0); savePosition(); speakCurrent() }
            page + 1 >= meta.total && meta.total > 0 && av >= meta.total -> {
                pause()
                AlertDialog.Builder(this).setMessage("آیا میخواهید از ابتدای کتاب صوتی گوش بدهید؟")
                    .setPositiveButton("شروع دوباره") { _, _ -> loadPage(0, 0); play() }
                    .setNegativeButton("خیر", null).show()
            }
            else -> {
                status.text = "منتظر پردازش صفحه‌ی بعد..."
                h.postDelayed({ if (playing && cur >= sents.size) nextPageAuto() }, 1000)
            }
        }
    }

    private fun togglePlay() { if (playing) pause() else play() }

    private fun play() {
        if (!loaded) { Ui.toast(this, "هنوز صفحه‌ای آماده نیست. لطفا منتظر بمانید."); return }
        stopVoicePlayer()
        playing = true
        playStart = System.currentTimeMillis()
        if (Prefs.bgRead(this) && !held) { WorkService.acquire(applicationContext); held = true }
        playBtn.setImageResource(R.drawable.ic_pause)
        playBtn.contentDescription = "مکث"
        applyVoiceSettings()
        speakCurrent()
    }

    private fun pause() {
        if (playing) {
            meta.readMs += System.currentTimeMillis() - playStart
            BookStore.update(this, meta.id) { it.readMs = meta.readMs }
        }
        playing = false
        token++
        tts?.stop()
        if (held) { WorkService.release(applicationContext); held = false }
        playBtn.setImageResource(R.drawable.ic_play)
        playBtn.contentDescription = "پخش"
    }

    private fun savePosition() {
        if (!loaded) return
        val off = sents.getOrNull(cur)?.start ?: curOff
        BookStore.update(this, meta.id) { it.page = page; it.offset = off }
    }

    // ---------------------------------------------------------------- navigation

    private fun units(): List<Seg> = when (Prefs.navMode(this)) {
        "page" -> listOf(Seg(0, text.length))
        "para" -> TextUtil.paragraphs(text)
        "sentence" -> sents
        else -> TextUtil.words(text)
    }

    private fun modeName(m: String) = when (m) {
        "page" -> "صفحه"; "para" -> "پاراگراف"; "sentence" -> "جمله"; else -> "کلمه"
    }

    private fun startFrom(off: Int) {
        if (!ttsReady) return
        stopVoicePlayer()
        curOff = off
        cur = TextUtil.indexAt(sents, off)
        if (!playing) {
            playing = true
            playStart = System.currentTimeMillis()
            if (Prefs.bgRead(this) && !held) { WorkService.acquire(applicationContext); held = true }
            playBtn.setImageResource(R.drawable.ic_pause)
            playBtn.contentDescription = "مکث"
        }
        speakCurrent()
    }

    private fun speakWord(off: Int, spell: Boolean) {
        if (playing) pause()
        val ws = TextUtil.words(text)
        if (ws.isEmpty()) return
        val w = ws[TextUtil.indexAt(ws, off)]
        curOff = w.start
        cur = TextUtil.indexAt(sents, w.start)
        render(w)
        val word = text.substring(w.start, w.end)
        val say = if (spell) word + "\u060C " + word.toCharArray().joinToString("\u060C ") else word
        if (ttsReady) speak(say)
    }

    private fun goOffset(off: Int) {
        when (Prefs.navMode(this)) {
            "word" -> speakWord(off, false)
            "wordspell" -> speakWord(off, true)
            else -> startFrom(off)
        }
    }

    private fun step(dir: Int) {
        if (!loaded) return
        val u = units()
        val i = if (u.isEmpty()) -1 else TextUtil.indexAt(u, curOff)
        val ni = i + dir
        if (ni in u.indices) { goOffset(u[ni].start); return }
        val np = page + dir
        if (np < 0) { Ui.toast(this, "صفحه‌ی قبلی نیست"); return }
        if (np >= available()) { Ui.toast(this, if (np >= meta.total) "صفحه‌ی بعدی نیست" else "صفحه‌ی بعدی هنوز پردازش نشده است"); return }
        loadPage(np, 0)
        val u2 = units()
        goOffset(if (dir < 0) (u2.lastOrNull()?.start ?: 0) else (u2.firstOrNull()?.start ?: 0))
    }

    /** About ten seconds of speech, counted in words. */
    private fun jump(dir: Int) {
        if (!loaded) return
        val n = (25 * Prefs.rate(this)).toInt().coerceAtLeast(5)
        val ws = TextUtil.words(text)
        val i = TextUtil.indexAt(ws, curOff) + dir * n
        if (i in ws.indices) { startFrom(ws[i].start); return }
        val np = page + dir
        if (np < 0) { startFrom(0); return }
        if (np >= available()) { Ui.toast(this, "صفحه‌ی بعدی نیست یا هنوز پردازش نشده است"); return }
        loadPage(np, 0)
        if (dir < 0) { val w2 = TextUtil.words(text); startFrom(w2.getOrNull(maxOf(w2.size - n, 0))?.start ?: 0) } else startFrom(0)
    }

    private fun replay() {
        if (!loaded) return
        val u = units()
        val s = if (u.isEmpty()) 0 else u[TextUtil.indexAt(u, curOff)].start
        goOffset(s)
    }

    private fun gotoPage(p: Int) {
        val wasPlaying = playing
        if (playing) pause()
        loadPage(p, 0)
        savePosition()
        if (wasPlaying) play()
    }

    // ---------------------------------------------------------------- settings menu

    private fun settingsMenu() {
        val mode = modeName(Prefs.navMode(this))
        Ui.choose(this, "تنظیمات", listOf(
            "تغییر حالت پیمایش (اکنون: $mode)",
            "تنظیم سرعت صوت (اکنون: ${Prefs.rate(this)})",
            "تنظیم زیر و بمی صوت (اکنون: ${Prefs.pitch(this)})",
            "تنظیم اندازه‌ی فونت (اکنون: ${Prefs.fontSp(this)})",
            "برو به صفحه‌ی...",
            "تنظیمات متن به گفتار و صدا، و تنظیمات برنامه"
        )) { i ->
            when (i) {
                0 -> navModeDialog()
                1 -> pickNumber("سرعت صوت", listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f)) { Prefs.setRate(this, it); applyVoiceSettings() }
                2 -> pickNumber("زیر و بمی صوت", listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)) { Prefs.setPitch(this, it); applyVoiceSettings() }
                3 -> pickNumber("اندازه‌ی فونت", listOf(14f, 16f, 18f, 20f, 24f, 28f, 34f, 40f)) { Prefs.setFontSp(this, it.toInt()); tv.textSize = it }
                4 -> Ui.input(this, "شماره‌ی صفحه را وارد کنید", (page + 1).toString(), false, true) { s ->
                    val n = s.toIntOrNull()
                    when {
                        n == null -> Ui.toast(this, "لطفا یک شماره صفحه‌ی معتبر وارد کنید")
                        n < 1 || n > meta.total -> Ui.toast(this, "حداکثر صفحات در این کتاب عبارت است از ${meta.total}")
                        n > available() -> Ui.toast(this, "این صفحه هنوز پردازش نشده است")
                        else -> gotoPage(n - 1)
                    }
                }
                5 -> startActivity(android.content.Intent(this, SettingsActivity::class.java))
            }
        }
    }

    private fun pickNumber(title: String, values: List<Float>, set: (Float) -> Unit) {
        Ui.choose(this, title, values.map { if (it == it.toInt().toFloat()) it.toInt().toString() else it.toString() }) { i ->
            set(values[i])
            Ui.toast(this, "تنظیم شد")
            if (playing) { val o = curOff; startFrom(o) }
        }
    }

    private fun navModeDialog() {
        val keys = listOf("page", "para", "sentence", "word", "wordspell")
        val names = listOf("خواندن صفحه به صفحه", "خواندن پاراگراف به پاراگراف", "خواندن جمله به جمله", "خواندن کلمه به کلمه", "خواندن کلمه به کلمه همراه با هجی کردن")
        Ui.choose(this, "تغییر حالت پیمایش در خواندن", names) { i ->
            Prefs.setNavMode(this, keys[i])
            val u = modeName(keys[i])
            Ui.toast(this, "حالت خواندن با موفقیت به حالت ${names[i]} تنظیم شد! دکمه‌ی بعدی و قبلی، $u را جابه‌جا می‌کنند.")
        }
    }

    // ---------------------------------------------------------------- tools menu

    private fun toolsMenu() {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(t: String, a: () -> Unit) { items.add(t); acts.add(a) }
        add("اشتراک‌گذاری") { shareMenu() }
        add("بارگیری") { saveMenu() }
        add("نشان‌گذاری صفحه و کلمه‌ی جاری") { addBookmark() }
        add("مشاهده‌ی نشان‌ها") { showBookmarks() }
        add("جستجو در متن") { searchDialog() }
        add("یادداشت‌های متنی") { notesDialog() }
        add("یادداشت‌های صوتی") { voiceNotesDialog() }
        add("ویرایش متن صفحه‌ی جاری") { editPage() }
        add("کپی کردن متن صفحه‌ی جاری") { copyPage() }
        add("متنِ ازقلم‌افتاده") { skipDialog() }
        add("آمار کتاب صوتی و پیگیری خواندن") { statsDialog() }
        add("تغییر نام کتاب صوتی") { renameDialog() }
        if (Processor.isRunning(meta.id)) add("توقف پردازش") { Ui.confirm(this, "آیا میخواهید پردازش را متوقف کنید؟") { Processor.cancel(meta.id); Ui.toast(this, "پردازشِ کتابِ صوتی لغو شد.") } }
        else if (meta.total > 0 && meta.done < meta.total) add("پردازشِ صفحه‌های باقیمانده") { Processor.start(this, meta.id); updateStatus() }
        add("پاک کردنِ کتاب صوتی") {
            Ui.confirm(this, "آیا میخواهید کتاب صوتیِ «${meta.name}» را پاک کنید؟") {
                pause(); Processor.cancel(meta.id); BookStore.delete(this, meta.id); Ui.toast(this, "کتاب صوتی پاک شد"); finish()
            }
        }
        Ui.choose(this, "ابزارها", items) { acts[it]() }
    }

    private fun shareMenu() {
        Ui.choose(this, "قالب اشتراک‌گذاری را انتخاب کنید", listOf("اشتراک‌گذاری به عنوان متن", "اشتراک‌گذاری به صورت DOCX", "اشتراک‌گذاری کتاب صوتی به عنوان فایل زیپ‌شده (همراه نشان‌ها، یادداشت‌ها و متن‌های ازقلم‌افتاده؛ برای پشتیبان‌گیری)")) { i ->
            Thread {
                try {
                    val f = when (i) { 0 -> Exporter.makeTxt(this, meta); 1 -> Exporter.makeDocx(this, meta); else -> Exporter.makeZip(this, meta) }
                    runOnUiThread { Exporter.share(this, f) }
                } catch (e: Exception) { runOnUiThread { Ui.toast(this, "اشتراک‌گذاری انجام نشد.") } }
            }.start()
        }
    }

    private fun saveMenu() {
        Ui.choose(this, "قالب بارگیری را انتخاب کنید", listOf("بارگیری به عنوان متن", "بارگیری به صورت DOCX", "بارگیری کتاب صوتی به عنوان فایل زیپ‌شده")) { i ->
            Thread {
                try {
                    val f = when (i) { 0 -> Exporter.makeTxt(this, meta); 1 -> Exporter.makeDocx(this, meta); else -> Exporter.makeZip(this, meta) }
                    pendingSave = f
                    runOnUiThread { saver.launch(f.name) }
                } catch (e: Exception) { runOnUiThread { Ui.toast(this, "بارگیری انجام نشد.") } }
            }.start()
        }
    }

    private fun snippet(): String {
        val s = text.getOrNull(curOff)?.let { text.substring(curOff, minOf(text.length, curOff + 60)) } ?: ""
        return s.replace('\n', ' ')
    }

    private fun addBookmark() {
        val l = BookStore.bookmarks(this, meta.id)
        l.add(Bookmark(page, curOff, snippet()))
        BookStore.setBookmarks(this, meta.id, l)
        Ui.toast(this, "صفحه و کلمه‌ی جاری نشان‌گذاری شدند!")
    }

    private fun showBookmarks() {
        val l = BookStore.bookmarks(this, meta.id)
        if (l.isEmpty()) { Ui.toast(this, "شما نشان‌گذاری‌ای برای این کتاب صوتی ندارید"); return }
        Ui.choose(this, "نشان‌ها", l.map { "صفحه‌ی ${it.page + 1}: ${it.snippet}" }) { i ->
            Ui.choose(this, "صفحه‌ی ${l[i].page + 1}", listOf("رفتن به این نشان", "پاک کردن این نشان")) { j ->
                if (j == 0) {
                    val b = l[i]
                    if (b.page >= available()) { Ui.toast(this, "شماره‌ی صفحه نامعتبر"); return@choose }
                    if (playing) pause()
                    loadPage(b.page, b.offset)
                } else {
                    l.removeAt(i)
                    BookStore.setBookmarks(this, meta.id, l)
                    Ui.toast(this, "نشان پاک شد")
                }
            }
        }
    }

    private fun searchDialog() {
        Ui.input(this, "متن جستجو را وارد کنید") { q0 ->
            val q = q0.trim()
            if (q.isEmpty()) { Ui.toast(this, "لطفا مقداری متن برای جستجو وارد کنید"); return@input }
            Thread {
                val hits = ArrayList<Triple<Int, Int, String>>()
                val n = available()
                loop@ for (p in 0 until n) {
                    val t = BookStore.pageText(this, meta.id, p)
                    var from = 0
                    while (true) {
                        val i = t.indexOf(q, from, true)
                        if (i < 0) break
                        val a = maxOf(0, i - 20)
                        hits.add(Triple(p, i, t.substring(a, minOf(t.length, i + 50)).replace('\n', ' ')))
                        if (hits.size >= 200) break@loop
                        from = i + q.length
                    }
                }
                runOnUiThread {
                    if (hits.isEmpty()) Ui.toast(this, "متن جستجو در کتاب صوتی پیدا نشد")
                    else Ui.choose(this, "نتایج جستجو", hits.map { "صفحه‌ی ${it.first + 1}: ${it.third}" }) { i ->
                        if (playing) pause()
                        loadPage(hits[i].first, hits[i].second)
                    }
                }
            }.start()
        }
    }

    private fun notesDialog() {
        Ui.input(this, "یادداشت‌ها", BookStore.notes(this, meta.id), true) { t ->
            BookStore.setNotes(this, meta.id, t)
            Ui.toast(this, "یادداشت‌ها ذخیره شدند!")
        }
    }

    private fun editPage() {
        if (!loaded) return
        Ui.input(this, "ویرایش متن", text, true) { t ->
            Ui.confirm(this, "آیا میخواهید متن ویرایش‌شده را ذخیره کنید؟") {
                if (playing) pause()
                BookStore.setPage(this, meta.id, page, t)
                loadPage(page, 0)
                Ui.toast(this, "متن ویرایش‌شده با موفقیت ذخیره شد!")
            }
        }
    }

    private fun copyPage() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("page", text))
        Ui.toast(this, "متن با موفقیت کپی شد!")
    }

    private fun skipDialog() {
        val l = BookStore.skipWords(this, meta.id)
        val items = ArrayList<String>()
        items.add("افزودن متنِ ازقلم‌افتاده‌ی جدید")
        items.addAll(l)
        Ui.choose(this, "متنِ ازقلم‌افتاده", items) { i ->
            if (i == 0) {
                Ui.input(this, "متنی را که میخواهید هنگام خواندن نادیده گرفته شود وارد کنید") { w ->
                    if (w.isBlank()) Ui.toast(this, "متنی که باید از قلم بیفتد را وارد کنید")
                    else { l.add(w.trim()); BookStore.setSkipWords(this, meta.id, l); skip = l; Ui.toast(this, "متن ازقلم‌افتاده با موفقیت افزوده شد") }
                }
            } else {
                Ui.confirm(this, "آیا میخواهید متن ازقلم‌افتاده‌ی «${l[i - 1]}» را پاک کنید؟") {
                    l.removeAt(i - 1); BookStore.setSkipWords(this, meta.id, l); skip = l; Ui.toast(this, "متن ازقلم‌افتاده پاک شد.")
                }
            }
        }
    }

    private fun statsDialog() {
        Thread {
            val n = available()
            var words = 0
            var paras = 0
            for (p in 0 until n) { val t = BookStore.pageText(this, meta.id, p); words += TextUtil.wordCount(t); paras += TextUtil.paragraphs(t).size }
            val wpm = 150 * Prefs.rate(this)
            val totalMin = (words / wpm).toInt()
            val curWords = TextUtil.wordCount(text)
            val curParas = TextUtil.paragraphs(text).size
            val readMin = (meta.readMs / 60000).toInt()
            val msg = "همه‌ی کلمات: $words\nهمه‌ی پاراگراف‌ها: $paras\nکل زمان خواندن (تخمینی): ${fmt(totalMin)}\n" +
                "زمان شنیده‌شده تا اکنون: ${fmt(readMin)}\n\nآمارِ صفحه‌ی ${page + 1}:\nکلمات صفحه: $curWords\nپاراگراف‌های صفحه: $curParas" +
                (if (meta.done < meta.total) "\n\nفرایندِ پردازشِ کتابِ صوتی کامل نشده؛ آمارِ کتاب با تمام شدن پردازش کامل می‌شود." else "")
            runOnUiThread { Ui.message(this, "آمار کتاب صوتی", msg) }
        }.start()
    }

    private fun fmt(min: Int): String = if (min >= 60) "${min / 60} ساعت و ${min % 60} دقیقه" else "$min دقیقه"

    private fun renameDialog() {
        Ui.input(this, "نام کتاب صوتی را وارد کنید", meta.name) { n ->
            if (n.isBlank()) Ui.toast(this, "لطفا نام کتاب صوتی را وارد کنید")
            else { BookStore.update(this, meta.id) { it.name = n.trim() }; refreshMeta() }
        }
    }

    // ---------------------------------------------------------------- voice notes

    private fun voiceNotesDialog() {
        val files = BookStore.voiceNotes(this, meta.id)
        val items = ArrayList<String>()
        items.add("ضبط صدا")
        items.addAll(files.map { it.name.removeSuffix(".m4a") })
        Ui.choose(this, "یادداشت‌های صوتی", items) { i ->
            if (i == 0) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
                else micPerm.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                val f = files[i - 1]
                Ui.choose(this, f.name.removeSuffix(".m4a"), listOf("پخش", "اشتراک‌گذاری یادداشت صوتی", "پاک کردن یادداشت صوتی")) { j ->
                    when (j) {
                        0 -> playVoice(f)
                        1 -> {
                            val tmp = File(File(cacheDir, "export").apply { mkdirs() }, f.name)
                            f.copyTo(tmp, true)
                            val uri = androidx.core.content.FileProvider.getUriForFile(this, packageName + ".files", tmp)
                            val it2 = android.content.Intent(android.content.Intent.ACTION_SEND)
                            it2.type = "audio/mp4"
                            it2.putExtra(android.content.Intent.EXTRA_STREAM, uri)
                            it2.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            startActivity(android.content.Intent.createChooser(it2, "اشتراک‌گذاری"))
                        }
                        2 -> Ui.confirm(this, "آیا میخواهید یادداشت صوتی را پاک کنید؟") { f.delete(); Ui.toast(this, "یادداشت صوتی پاک شد") }
                    }
                }
            }
        }
    }

    private fun startRecording() {
        if (playing) pause()
        stopVoicePlayer()
        val f = File(BookStore.voiceDir(this, meta.id), "tmp_record.m4a")
        try {
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recFile = f
        } catch (e: Exception) {
            Ui.toast(this, "ضبط صدا انجام نشد.")
            return
        }
        AlertDialog.Builder(this).setTitle("در حال ضبط صدا")
            .setCancelable(false)
            .setPositiveButton("توقف و ذخیره") { _, _ -> finishRecording() }
            .setNegativeButton("لغو") { _, _ -> cancelRecording() }
            .show()
    }

    private fun stopRecorder() {
        try { recorder?.stop() } catch (e: Exception) { }
        try { recorder?.release() } catch (e: Exception) { }
        recorder = null
    }

    private fun cancelRecording() { stopRecorder(); recFile?.delete() }

    private fun finishRecording() {
        stopRecorder()
        val tmp = recFile ?: return
        Ui.toast(this, "ضبط متوقف شد")
        val def = "یادداشت " + (BookStore.voiceNotes(this, meta.id).size + 1)
        Ui.input(this, "نام یادداشت صوتی را وارد کنید", def) { n ->
            val name = n.trim().replace(Regex("[\\\\/:*?\"<>|]"), " ").ifEmpty { def }
            val dest = File(tmp.parentFile, "$name.m4a")
            if (dest.exists()) { Ui.toast(this, "نام یادداشت صوتی از قبل وجود دارد. نام دیگری وارد کنید."); tmp.delete() }
            else { tmp.renameTo(dest); Ui.toast(this, "یادداشت صوتی با موفقیت ذخیره شد!") }
        }
    }

    private fun playVoice(f: File) {
        if (playing) pause()
        stopVoicePlayer()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            mp.setOnCompletionListener { stopVoicePlayer() }
            mp.start()
            player = mp
        } catch (e: Exception) { Ui.toast(this, "پخش انجام نشد.") }
    }

    private fun stopVoicePlayer() {
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        player = null
    }
}
