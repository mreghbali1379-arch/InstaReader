package com.example.ketabkhan

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import kotlin.math.max
import kotlin.math.sqrt

/** Page pictures: enlarge to a good size and turn into clean black text on white. */
object PagePrep {
    private const val MAX_PIXELS = 6_000_000
    private const val MIN_SIDE = 1600

    private fun scaled(src: Bitmap): Bitmap {
        val px = src.width.toLong() * src.height
        var f = 1f
        if (px > MAX_PIXELS) f = sqrt(MAX_PIXELS.toFloat() / px)
        else if (max(src.width, src.height) < MIN_SIDE) f = MIN_SIDE.toFloat() / max(src.width, src.height)
        if (f > 0.99f && f < 1.01f) return src
        val w = (src.width * f).toInt().coerceAtLeast(1)
        val h = (src.height * f).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, w, h, true)
    }

    /** Plain gray version (used when the clean-up version gives no text). */
    fun gray(src: Bitmap): Bitmap {
        val s = scaled(src)
        val w = s.width
        val h = s.height
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            val l = (((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000
            px[i] = Color.rgb(l, l, l)
        }
        if (s !== src) s.recycle()
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Adaptive black/white conversion: copes with shadows and uneven light on photographed pages. */
    fun prepare(src: Bitmap): Bitmap {
        val s = scaled(src)
        val w = s.width
        val h = s.height
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== src) s.recycle()
        val g = IntArray(w * h)
        for (i in px.indices) {
            val p = px[i]
            g[i] = (((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000
        }
        val w1 = w + 1
        val integral = IntArray(w1 * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                row += g[y * w + x]
                integral[(y + 1) * w1 + (x + 1)] = integral[y * w1 + (x + 1)] + row
            }
        }
        val half = max(w / 16, 15) / 2
        for (y in 0 until h) {
            val y1 = max(0, y - half)
            val y2 = minOf(h - 1, y + half)
            for (x in 0 until w) {
                val x1 = max(0, x - half)
                val x2 = minOf(w - 1, x + half)
                val count = (x2 - x1 + 1) * (y2 - y1 + 1)
                val sum = integral[(y2 + 1) * w1 + (x2 + 1)] - integral[y1 * w1 + (x2 + 1)] -
                    integral[(y2 + 1) * w1 + x1] + integral[y1 * w1 + x1]
                // black when the pixel is clearly darker than its surroundings
                px[y * w + x] = if (g[y * w + x].toLong() * count * 100 <= sum.toLong() * 85) Color.BLACK else Color.WHITE
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}

/** Offline OCR with Tesseract (Persian and English). */
class OcrHelper(private val context: Context) {
    private val fastDir = File(context.filesDir, "tessdata").apply { mkdirs() }
    private val bestDir = File(File(context.filesDir, "best"), "tessdata").apply { mkdirs() }
    private var api: TessBaseAPI? = null
    private var copied = false

    private fun filesIn(d: File): List<String> =
        d.listFiles { f -> f.name.endsWith(".traineddata") }
            ?.map { it.name.removeSuffix(".traineddata") }
            ?.sortedBy { if (it == "fas") 0 else 1 } ?: emptyList()

    private fun currentDir(): File =
        if (Prefs.ocrModel(context) == "best" && filesIn(bestDir).isNotEmpty()) bestDir else fastDir

    private fun copyDir(assetDir: String, target: File, stamp: String) {
        val marker = File(target, ".stamp")
        val force = !marker.exists() || marker.readText() != stamp
        context.assets.list(assetDir)?.filter { it.endsWith(".traineddata") }?.forEach { n ->
            val f = File(target, n)
            if (force || !f.exists()) context.assets.open("$assetDir/$n").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
        if (force) marker.writeText(stamp)
    }

    private fun copyAssets() {
        if (copied) return
        try {
            val stamp = try {
                context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime.toString()
            } catch (e: Exception) { "" }
            copyDir("tessdata", fastDir, stamp)
            copyDir("tessdata_best", bestDir, stamp)
            copied = true
        } catch (ignored: Exception) { }
    }

    fun hasData(): Boolean { copyAssets(); return filesIn(currentDir()).isNotEmpty() }

    private fun ensureApi(): TessBaseAPI? {
        copyAssets()
        val dir = currentDir()
        val langs = filesIn(dir)
        if (langs.isEmpty()) return null
        val pref = Prefs.ocrLang(context)
        val use = if (pref != "all" && langs.contains(pref)) listOf(pref) else langs
        api?.let { return it }
        val a = TessBaseAPI()
        if (!a.init(dir.parentFile!!.absolutePath, use.joinToString("+"))) { a.recycle(); return null }
        a.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
        api = a
        return a
    }

    /** Reads one page picture. Returns null if no language file is installed. The picture is not recycled. */
    fun recognize(src: Bitmap): String? {
        val a = ensureApi() ?: return null
        val b = PagePrep.prepare(src)
        var t = ""
        try {
            a.setImage(b)
            t = TextFix.fixPage(a.getUTF8Text() ?: "")
        } finally {
            b.recycle()
        }
        if (t.length < 8) {
            // nothing found after the clean-up: try the plain gray picture
            val g = PagePrep.gray(src)
            try {
                a.setImage(g)
                val t2 = TextFix.fixPage(a.getUTF8Text() ?: "")
                if (t2.length > t.length) t = t2
            } finally {
                g.recycle()
            }
        }
        return t
    }

    fun release() { try { api?.recycle() } catch (ignored: Exception) { }; api = null }
}
