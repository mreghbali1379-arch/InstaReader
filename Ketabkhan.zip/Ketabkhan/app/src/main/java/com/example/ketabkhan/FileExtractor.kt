package com.example.ketabkhan

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipFile

/** Gets the text of DOCX, PPTX, XLSX and TXT files and splits it into pages. */
object FileExtractor {
    private fun parser(input: InputStream): XmlPullParser {
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(input, "UTF-8")
        return p
    }

    private fun local(n: String?): String = (n ?: "").substringAfter(':')

    /** Paragraph text of Word and PowerPoint XML (t = text run, p = paragraph). */
    private fun paragraphsOf(input: InputStream): String {
        val p = parser(input)
        val out = StringBuilder()
        val para = StringBuilder()
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (local(p.name)) {
                    "t" -> inT = true
                    "tab" -> para.append(' ')
                    "br" -> para.append('\n')
                }
                XmlPullParser.TEXT -> if (inT) para.append(p.text)
                XmlPullParser.END_TAG -> when (local(p.name)) {
                    "t" -> inT = false
                    "p" -> {
                        val s = para.toString().trim()
                        if (s.isNotEmpty()) out.append(s).append('\n')
                        para.setLength(0)
                    }
                }
            }
            ev = p.next()
        }
        return out.toString()
    }

    private fun docx(f: File): String {
        ZipFile(f).use { z ->
            val e = z.getEntry("word/document.xml") ?: return ""
            return z.getInputStream(e).use { paragraphsOf(it) }
        }
    }

    private fun numberOf(name: String): Int = Regex("(\\d+)\\.xml$").find(name)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    private fun pptx(f: File): List<String> {
        val pages = ArrayList<String>()
        ZipFile(f).use { z ->
            val slides = z.entries().toList()
                .filter { Regex("^ppt/slides/slide\\d+\\.xml$").matches(it.name) }
                .sortedBy { numberOf(it.name) }
            for (e in slides) pages.add(z.getInputStream(e).use { paragraphsOf(it) }.trim())
        }
        return pages
    }

    private fun xlsx(f: File): String {
        val out = StringBuilder()
        ZipFile(f).use { z ->
            val shared = ArrayList<String>()
            z.getEntry("xl/sharedStrings.xml")?.let { e ->
                z.getInputStream(e).use { ins ->
                    val p = parser(ins)
                    val sb = StringBuilder()
                    var inT = false
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        when (ev) {
                            XmlPullParser.START_TAG -> when (local(p.name)) {
                                "si" -> sb.setLength(0)
                                "t" -> inT = true
                            }
                            XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                            XmlPullParser.END_TAG -> when (local(p.name)) {
                                "t" -> inT = false
                                "si" -> shared.add(sb.toString())
                            }
                        }
                        ev = p.next()
                    }
                }
            }
            val sheets = z.entries().toList()
                .filter { Regex("^xl/worksheets/sheet\\d+\\.xml$").matches(it.name) }
                .sortedBy { numberOf(it.name) }
            for (e in sheets) {
                z.getInputStream(e).use { ins ->
                    val p = parser(ins)
                    val cell = StringBuilder()
                    val row = ArrayList<String>()
                    var type = ""
                    var inV = false
                    var inT = false
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        when (ev) {
                            XmlPullParser.START_TAG -> when (local(p.name)) {
                                "c" -> { type = p.getAttributeValue(null, "t") ?: ""; cell.setLength(0) }
                                "v" -> inV = true
                                "t" -> inT = true
                            }
                            XmlPullParser.TEXT -> if (inV || inT) cell.append(p.text)
                            XmlPullParser.END_TAG -> when (local(p.name)) {
                                "v" -> inV = false
                                "t" -> inT = false
                                "c" -> {
                                    val v = if (type == "s") shared.getOrNull(cell.toString().trim().toIntOrNull() ?: -1) ?: "" else cell.toString()
                                    if (v.isNotBlank()) row.add(v.trim())
                                }
                                "row" -> {
                                    if (row.isNotEmpty()) out.append(row.joinToString("\u060C ")).append('\n')
                                    row.clear()
                                }
                            }
                        }
                        ev = p.next()
                    }
                }
            }
        }
        return out.toString()
    }

    private fun txt(f: File): String {
        val bytes = f.readBytes()
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString().removePrefix("\uFEFF")
        } catch (e: CharacterCodingException) {
            String(bytes, Charset.forName("windows-1256"))
        }
    }

    /** Splits a long text into pages of about [size] characters, at paragraph ends where possible. */
    fun paginate(text: String, size: Int = 2200): List<String> {
        val pages = ArrayList<String>()
        val sb = StringBuilder()
        for (line in text.split('\n')) {
            var l = line.trim()
            if (l.isEmpty()) continue
            while (l.length > size) {
                var cut = l.lastIndexOf(' ', size)
                if (cut <= 0) cut = size
                if (sb.isNotEmpty()) { pages.add(sb.toString().trim()); sb.setLength(0) }
                pages.add(l.substring(0, cut).trim())
                l = l.substring(cut).trim()
            }
            if (sb.isNotEmpty() && sb.length + l.length > size) {
                pages.add(sb.toString().trim())
                sb.setLength(0)
            }
            if (l.isNotEmpty()) sb.append(l).append("\n\n")
        }
        if (sb.isNotBlank()) pages.add(sb.toString().trim())
        if (pages.isEmpty()) pages.add("")
        return pages
    }

    fun pages(src: File, kind: String): List<String> = when (kind) {
        "docx" -> paginate(docx(src))
        "pptx" -> pptx(src).ifEmpty { listOf("") }
        "xlsx" -> paginate(xlsx(src))
        else -> paginate(txt(src))
    }
}
