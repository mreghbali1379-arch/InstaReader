package com.example.ketabkhan

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Share and save a book as text, Word file or zip backup. */
object Exporter {
    private fun exportDir(c: Context) = File(c.cacheDir, "export").apply { mkdirs() }

    private fun safeName(n: String): String = n.replace(Regex("[\\\\/:*?\"<>|\\n]"), " ").trim().ifEmpty { "book" }

    fun allText(c: Context, m: BookMeta, withNumbers: Boolean): String {
        val sb = StringBuilder()
        for (i in 0 until m.done) {
            if (withNumbers) sb.append("— صفحه ").append(i + 1).append(" —\n")
            sb.append(BookStore.pageText(c, m.id, i)).append("\n\n")
        }
        return sb.toString().trim()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun makeTxt(c: Context, m: BookMeta): File {
        val f = File(exportDir(c), safeName(m.name) + ".txt")
        f.writeText(allText(c, m, true))
        return f
    }

    fun makeDocx(c: Context, m: BookMeta): File {
        val f = File(exportDir(c), safeName(m.name) + ".docx")
        val body = StringBuilder()
        for (line in allText(c, m, true).split('\n')) {
            if (line.isBlank()) continue
            body.append("<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:rtl/></w:rPr><w:t xml:space=\"preserve\">")
                .append(esc(line)).append("</w:t></w:r></w:p>")
        }
        ZipOutputStream(f.outputStream()).use { z ->
            fun put(name: String, text: String) { z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>")
            put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>")
            put("word/document.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$body</w:body></w:document>")
        }
        return f
    }

    /** Backup of the whole book (pages, notes, bookmarks, skipped text, voice notes). */
    fun makeZip(c: Context, m: BookMeta): File {
        val f = File(exportDir(c), safeName(m.name) + ".zip")
        val root = BookStore.dir(c, m.id)
        ZipOutputStream(f.outputStream()).use { z ->
            root.walkTopDown().filter { it.isFile }.forEach { file ->
                z.putNextEntry(ZipEntry(file.relativeTo(root).path.replace('\\', '/')))
                file.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return f
    }

    /** Restores a zip backup as a new book. Returns false if the file is not a valid backup. */
    fun importZip(c: Context, zip: File): Boolean {
        val id = BookStore.newId()
        val target = BookStore.dir(c, id)
        try {
            java.util.zip.ZipFile(zip).use { z ->
                if (z.getEntry("meta.json") == null) { target.deleteRecursively(); return false }
                for (e in z.entries()) {
                    if (e.isDirectory) continue
                    val out = File(target, e.name)
                    // refuse paths that leave the book folder
                    if (!out.canonicalPath.startsWith(target.canonicalPath + File.separator)) continue
                    out.parentFile?.mkdirs()
                    z.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                }
            }
            val m = BookStore.load(c, id)
            if (m == null) { target.deleteRecursively(); return false }
            m.id = id
            m.created = System.currentTimeMillis()
            BookStore.save(c, m)
            return true
        } catch (e: Exception) {
            target.deleteRecursively()
            return false
        }
    }

    fun mimeOf(f: File): String = when (f.extension) {
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "zip" -> "application/zip"
        else -> "text/plain"
    }

    fun share(a: Activity, f: File) {
        val uri = FileProvider.getUriForFile(a, a.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND)
        i.type = mimeOf(f)
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        a.startActivity(Intent.createChooser(i, "اشتراک‌گذاری"))
    }

    fun shareText(a: Activity, text: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, text)
        a.startActivity(Intent.createChooser(i, "اشتراک‌گذاری"))
    }
}
