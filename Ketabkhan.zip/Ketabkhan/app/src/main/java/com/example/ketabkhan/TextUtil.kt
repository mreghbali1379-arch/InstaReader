package com.example.ketabkhan

/** A range of characters inside a page text. */
class Seg(val start: Int, val end: Int)

object TextUtil {
    private const val ENDERS = ".!?\u061F\u06D4\u2026"
    private const val CLOSERS = "\"\u00BB\u201D)"
    private const val MAX_SEG = 300

    private fun addTrimmed(out: MutableList<Seg>, t: String, from: Int, to: Int) {
        var s = from
        var e = to
        while (s < e && t[s].isWhitespace()) s++
        while (e > s && t[e - 1].isWhitespace()) e--
        if (s >= e) return
        // very long pieces are cut at a space so the speech engine gets manageable parts
        while (e - s > MAX_SEG) {
            var cut = t.lastIndexOf(' ', s + MAX_SEG)
            if (cut <= s) cut = s + MAX_SEG
            out.add(Seg(s, cut))
            s = cut
            while (s < e && t[s].isWhitespace()) s++
        }
        if (s < e) out.add(Seg(s, e))
    }

    /** Sentences of a page (also split at line breaks). */
    fun sentences(t: String): List<Seg> {
        val out = ArrayList<Seg>()
        var s = 0
        val n = t.length
        var i = 0
        while (i < n) {
            val ch = t[i]
            val cut = ch == '\n' || (ENDERS.indexOf(ch) >= 0 &&
                (i + 1 >= n || t[i + 1].isWhitespace() || CLOSERS.indexOf(t[i + 1]) >= 0))
            if (cut) {
                addTrimmed(out, t, s, i + 1)
                s = i + 1
            }
            i++
        }
        addTrimmed(out, t, s, n)
        return out
    }

    /** Paragraphs: non-empty lines. */
    fun paragraphs(t: String): List<Seg> {
        val out = ArrayList<Seg>()
        var s = 0
        for (i in 0..t.length) {
            if (i == t.length || t[i] == '\n') {
                var a = s
                var b = i
                while (a < b && t[a].isWhitespace()) a++
                while (b > a && t[b - 1].isWhitespace()) b--
                if (a < b) out.add(Seg(a, b))
                s = i + 1
            }
        }
        return out
    }

    fun words(t: String): List<Seg> {
        val out = ArrayList<Seg>()
        var i = 0
        val n = t.length
        while (i < n) {
            while (i < n && t[i].isWhitespace()) i++
            val s = i
            while (i < n && !t[i].isWhitespace()) i++
            if (i > s) out.add(Seg(s, i))
        }
        return out
    }

    /** Index of the last unit that starts at or before [offset]. */
    fun indexAt(list: List<Seg>, offset: Int): Int {
        var r = 0
        for (i in list.indices) { if (list[i].start <= offset) r = i else break }
        return r
    }

    /** "fa" if the text is mostly Arabic-script, otherwise "en". */
    fun lang(s: String): String {
        var fa = 0
        var en = 0
        for (c in s) {
            if (c in '\u0600'..'\u06FF' || c in '\uFB50'..'\uFEFF') fa++
            else if (c in 'a'..'z' || c in 'A'..'Z') en++
        }
        return if (fa >= en) "fa" else "en"
    }

    fun wordCount(t: String): Int = words(t).size
}
