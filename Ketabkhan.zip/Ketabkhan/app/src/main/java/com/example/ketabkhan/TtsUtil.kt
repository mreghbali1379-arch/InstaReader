package com.example.ketabkhan

import android.speech.tts.TextToSpeech
import java.util.Locale

object TtsUtil {
    // Different engines (eSpeak, Google, Samsung...) report Persian under different codes.
    private val tags = listOf("fa", "fa-IR", "fas", "per", "pes", "fa-AF")

    /** Tries Persian under several codes. Returns true if the engine accepted one. */
    fun usePersian(t: TextToSpeech): Boolean {
        for (tag in tags) {
            val r = try {
                t.setLanguage(Locale.forLanguageTag(tag))
            } catch (e: Exception) {
                TextToSpeech.LANG_NOT_SUPPORTED
            }
            if (r >= TextToSpeech.LANG_AVAILABLE) return true
        }
        return false
    }

    fun useEnglish(t: TextToSpeech): Boolean = try {
        t.setLanguage(Locale.US) >= TextToSpeech.LANG_AVAILABLE
    } catch (e: Exception) { false }

    fun isPersianVoice(l: Locale): Boolean {
        val c = l.language.lowercase(Locale.ROOT)
        return c == "fa" || c == "per" || c == "pes" || c == "fas"
    }
}
